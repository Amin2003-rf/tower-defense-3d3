// Native Android LAN WebSocket server. Browser builds keep using server/server.js.
// '@capacitor/core' only resolves inside the APK bundle; in a normal browser the import fails harmlessly.
let Capacitor = null, registerPlugin = null;
try { ({ Capacitor, registerPlugin } = await import('@capacitor/core')); } catch (e) { /* plain web build */ }

const LocalRoomServer = registerPlugin ? registerPlugin('LocalRoomServer') : null;

export const isNativeAndroid = () => !!Capacitor && Capacitor.getPlatform() === 'android';

export async function startLocalRoomServer() {
  if (!isNativeAndroid()) return null;
  return LocalRoomServer.startServer({ port: 8765 });
}

export async function stopLocalRoomServer() {
  if (!isNativeAndroid()) return;
  try { await LocalRoomServer.stopServer(); } catch (e) { console.warn('Could not stop local room server', e); }
}
