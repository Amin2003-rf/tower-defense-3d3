package com.towerdefense.game;

import android.util.Log;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.net.Inet4Address;
import java.net.NetworkInterface;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;

@CapacitorPlugin(name = "LocalRoomServer")
public class LocalRoomServerPlugin extends Plugin {
    private LocalRoomWebSocketServer server;

    @PluginMethod
    public void startServer(PluginCall call) {
        int port = call.getInt("port", 8765);
        try {
            if (server == null) {
                LocalRoomWebSocketServer newServer = new LocalRoomWebSocketServer(port);
                newServer.start();
                // Wait for WebSocketServer.onStart so JavaScript does not race
                // the socket bind and attempt to connect too early.
                if (!newServer.awaitStarted(5000)) {
                    try { newServer.stop(250); } catch (Exception ignored) { }
                    throw new IllegalStateException("Local WebSocket server did not start on port " + port);
                }
                server = newServer;
            }
            com.getcapacitor.JSObject result = new com.getcapacitor.JSObject();
            result.put("port", port);
            result.put("addresses", getIPv4Addresses());
            call.resolve(result);
        } catch (Exception e) {
            Log.e("LocalRoomServer", "Unable to start LAN server", e);
            call.reject("Unable to start local server: " + e.getMessage(), e);
        }
    }

    @PluginMethod
    public void stopServer(PluginCall call) {
        try {
            if (server != null) {
                server.stop(500);
                server = null;
            }
            call.resolve();
        } catch (Exception e) {
            call.reject("Unable to stop local server: " + e.getMessage(), e);
        }
    }

    private List<String> getIPv4Addresses() throws Exception {
        // Android hotspot/Wi-Fi interface names vary by device and OS version
        // (wlan0, ap0, swlan0, etc.). Do not rely on interface-name matching
        // alone; collect valid IPv4 addresses and prioritize private LAN IPs.
        List<String> privateIps = new ArrayList<>();
        List<String> otherIps = new ArrayList<>();
        Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
        if (interfaces == null) return otherIps;

        while (interfaces.hasMoreElements()) {
            NetworkInterface ni = interfaces.nextElement();
            try {
                if (!ni.isUp() || ni.isLoopback()) continue;
            } catch (Exception ignored) { continue; }

            Enumeration<java.net.InetAddress> addresses = ni.getInetAddresses();
            while (addresses.hasMoreElements()) {
                java.net.InetAddress address = addresses.nextElement();
                if (!(address instanceof Inet4Address)) continue;
                if (address.isLoopbackAddress() || address.isLinkLocalAddress() || address.isAnyLocalAddress()) continue;

                String ip = address.getHostAddress();
                if (ip == null || ip.isEmpty() || ip.contains("%")) continue;
                if (isPrivateIPv4(ip)) {
                    if (!privateIps.contains(ip)) privateIps.add(ip);
                } else if (!otherIps.contains(ip)) {
                    otherIps.add(ip);
                }
            }
        }

        // Private LAN addresses (typically Wi-Fi/hotspot) are the most useful
        // addresses for joining from another device on the same network.
        privateIps.addAll(otherIps);
        return privateIps;
    }

    private boolean isPrivateIPv4(String ip) {
        return ip.startsWith("10.") || ip.startsWith("192.168.") ||
               (ip.startsWith("172.") && is172Private(ip));
    }

    private boolean is172Private(String ip) {
        try {
            String[] parts = ip.split("\\.");
            int second = Integer.parseInt(parts[1]);
            return second >= 16 && second <= 31;
        } catch (Exception ignored) { return false; }
    }
}
